package MainPackage;

public class SubClass extends ParentClass {
    public SubClass(int defaultValue) {
        setValue(defaultValue);
    }
}
