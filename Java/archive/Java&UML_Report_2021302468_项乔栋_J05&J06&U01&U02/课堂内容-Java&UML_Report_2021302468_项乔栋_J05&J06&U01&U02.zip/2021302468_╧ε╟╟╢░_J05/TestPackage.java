import p1.DefiPackage;

public class TestPackage {
    public static void main(String[] args) {
        DefiPackage t = new DefiPackage();
        t.display();
    }
}
